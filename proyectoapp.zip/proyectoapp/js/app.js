// =========================================================
// ========== INICIALIZACIÓN DE BASES DE DATOS ==============
// =========================================================

// Usuarios
if (!localStorage.getItem("usuarios")) {
    localStorage.setItem("usuarios", JSON.stringify([]));
}

// Sesión actual
if (!localStorage.getItem("sesion")) {
    localStorage.setItem("sesion", JSON.stringify(null));
}

// Clientes
if (!localStorage.getItem("clientes")) {
    localStorage.setItem("clientes", JSON.stringify([]));
}

// Membresías
if (!localStorage.getItem("membresias")) {
    localStorage.setItem("membresias", JSON.stringify([]));
}

// Rutinas
if (!localStorage.getItem("rutinas")) {
    localStorage.setItem("rutinas", JSON.stringify([]));
}



// =========================================================
// ========================= REGISTRO =======================
// =========================================================
if (document.getElementById("registerForm")) {

    document.getElementById("registerForm").addEventListener("submit", function (e) {
        e.preventDefault();

        const nombre = document.getElementById("regNombre").value;
        const email = document.getElementById("regEmail").value;
        const pass = document.getElementById("regPass").value;
        const pass2 = document.getElementById("regPass2").value;

        if (pass !== pass2) {
            alert("Las contraseñas NO coinciden");
            return;
        }

        let usuarios = JSON.parse(localStorage.getItem("usuarios"));

        if (usuarios.some(u => u.email === email)) {
            alert("Este usuario YA existe");
            return;
        }

        usuarios.push({ nombre, email, pass });
        localStorage.setItem("usuarios", JSON.stringify(usuarios));

        alert("Registro exitoso. Ahora inicia sesión.");
        window.location.href = "index.html";
    });
}



// =========================================================
// =========================== LOGIN =========================
// =========================================================
if (document.getElementById("loginForm")) {

    document.getElementById("loginForm").addEventListener("submit", function (e) {
        e.preventDefault();

        const email = document.getElementById("loginEmail").value;
        const pass = document.getElementById("loginPassword").value;

        let usuarios = JSON.parse(localStorage.getItem("usuarios"));
        let user = usuarios.find(u => u.email === email && u.pass === pass);

        if (!user) {
            alert("Credenciales incorrectas");
            return;
        }

        localStorage.setItem("sesion", JSON.stringify(user));

        alert("Bienvenido " + user.nombre);
        window.location.href = "paginas/home.html";
    });
}



// =========================================================
// ========== VERIFICAR SESIÓN EN PÁGINAS INTERNAS ==========
// =========================================================
if (window.location.pathname.includes("/paginas/")) {
    const sesion = JSON.parse(localStorage.getItem("sesion"));

    if (!sesion) {
        alert("Debes iniciar sesión");
        window.location.href = "../index.html";
    }
}



// =========================================================
// ==================== CRUD DE CLIENTES ====================
// =========================================================

if (window.location.pathname.includes("clientes.html")) {
    cargarComboMembresiasParaClientes();
    cargarTablaClientes();
    cargarComboClientes();
}

// Cargar membresías en el select de Clientes
function cargarComboMembresiasParaClientes() {
    let combo = document.getElementById("clienteMembresia");
    if (!combo) return;

    combo.innerHTML = `<option value="">Seleccione membresía</option>`;

    let mems = JSON.parse(localStorage.getItem("membresias"));

    mems.forEach(m => {
        combo.innerHTML += `<option value="${m.id}">${m.nombre}</option>`;
    });
}

// Agregar Cliente
function agregarCliente() {
    let nombre = document.getElementById("clienteNombre").value;
    let edad = document.getElementById("clienteEdad").value;
    let tel = document.getElementById("clienteTelefono").value;
    let mem = document.getElementById("clienteMembresia").value;

    if (!nombre || !edad || !tel || !mem) {
        alert("Todos los campos son obligatorios");
        return;
    }

    let clientes = JSON.parse(localStorage.getItem("clientes"));

    let nuevo = {
        id: clientes.length + 1,
        nombre,
        edad,
        telefono: tel,
        membresia: mem // ← se guarda el ID, no el nombre
    };

    clientes.push(nuevo);
    localStorage.setItem("clientes", JSON.stringify(clientes));

    alert("Cliente registrado");
    limpiarFormularioCliente();
    cargarTablaClientes();
    cargarComboClientes();
}

// Buscar Cliente por ID
function buscarClientePorID() {
    let id = document.getElementById("comboBuscarCliente").value;
    if (id === "") return;

    let clientes = JSON.parse(localStorage.getItem("clientes"));
    let cli = clientes.find(c => c.id == id);

    if (!cli) return;

    document.getElementById("clienteId").value = cli.id;
    document.getElementById("clienteNombre").value = cli.nombre;
    document.getElementById("clienteEdad").value = cli.edad;
    document.getElementById("clienteTelefono").value = cli.telefono;
    document.getElementById("clienteMembresia").value = cli.membresia;
}

// Modificar Cliente
function modificarCliente() {
    let id = document.getElementById("clienteId").value;
    if (!id) {
        alert("Selecciona un cliente para modificar.");
        return;
    }

    let clientes = JSON.parse(localStorage.getItem("clientes"));
    let i = clientes.findIndex(c => c.id == id);

    clientes[i].nombre = document.getElementById("clienteNombre").value;
    clientes[i].edad = document.getElementById("clienteEdad").value;
    clientes[i].telefono = document.getElementById("clienteTelefono").value;
    clientes[i].membresia = document.getElementById("clienteMembresia").value;

    localStorage.setItem("clientes", JSON.stringify(clientes));

    alert("Cliente actualizado");
    limpiarFormularioCliente();
    cargarTablaClientes();
    cargarComboClientes();
}

// Eliminar Cliente
function eliminarCliente() {
    let id = document.getElementById("clienteId").value;
    if (!id) {
        alert("Selecciona un cliente para eliminar.");
        return;
    }

    let clientes = JSON.parse(localStorage.getItem("clientes"));
    clientes = clientes.filter(c => c.id != id);

    localStorage.setItem("clientes", JSON.stringify(clientes));

    alert("Cliente eliminado");
    limpiarFormularioCliente();
    cargarTablaClientes();
    cargarComboClientes();
}

// Tabla Clientes (con membresía traducida a nombre)
function cargarTablaClientes() {
    fetch("../clientes_lista.php")
        .then(response => response.json())
        .then(clientes => {

            let tabla = document.getElementById("tablaClientes");

            tabla.innerHTML = `
                <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Edad</th>
                    <th>Teléfono</th>
                    <th>Membresía</th>
                </tr>
            `;

            clientes.forEach(cli => {
                tabla.innerHTML += `
                    <tr>
                        <td>${cli.id}</td>
                        <td>${cli.nombre}</td>
                        <td>${cli.edad}</td>
                        <td>${cli.telefono}</td>
                        <td>${cli.membresia || "N/A"}</td>
                    </tr>
                `;
            });

        });
}

// Combo búsqueda clientes
function cargarComboClientes() {
    let combo = document.getElementById("comboBuscarCliente");
    if (!combo) return;

    combo.innerHTML = `<option value="">Selecciona un cliente</option>`;

    let clientes = JSON.parse(localStorage.getItem("clientes"));

    clientes.forEach(c => {
        combo.innerHTML += `<option value="${c.id}">${c.id} - ${c.nombre}</option>`;
    });
}

// Limpiar formulario
function limpiarFormularioCliente() {
    document.getElementById("clienteId").value = "";
    document.getElementById("clienteNombre").value = "";
    document.getElementById("clienteEdad").value = "";
    document.getElementById("clienteTelefono").value = "";
    document.getElementById("clienteMembresia").value = "";
}



// =========================================================
// ================= CRUD DE MEMBRESÍAS =====================
// =========================================================

if (window.location.pathname.includes("membresias.html")) {
    cargarTablaMembresias();
    cargarComboMembresias();
}

// Agregar membresía
function agregarMembresia() {
    let nombre = document.getElementById("memNombre").value;
    let duracion = document.getElementById("memDuracion").value;
    let precio = document.getElementById("memPrecio").value;

    if (!nombre || !duracion || !precio) {
        alert("Todos los campos son obligatorios");
        return;
    }

    let mems = JSON.parse(localStorage.getItem("membresias"));

    let nueva = {
        id: mems.length + 1,
        nombre,
        duracion,
        precio
    };

    mems.push(nueva);
    localStorage.setItem("membresias", JSON.stringify(mems));

    alert("Membresía registrada");
    limpiarFormularioMembresia();
    cargarTablaMembresias();
    cargarComboMembresias();
}

// Buscar membresía
function buscarMembresiaPorID() {
    let id = document.getElementById("comboBuscarMembresia").value;
    if (id === "") return;

    let mems = JSON.parse(localStorage.getItem("membresias"));
    let m = mems.find(x => x.id == id);

    if (!m) return;

    document.getElementById("memId").value = m.id;
    document.getElementById("memNombre").value = m.nombre;
    document.getElementById("memDuracion").value = m.duracion;
    document.getElementById("memPrecio").value = m.precio;
}

// Modificar membresía
function modificarMembresia() {
    let id = document.getElementById("memId").value;

    if (!id) {
        alert("Selecciona una membresía para modificar.");
        return;
    }

    let mems = JSON.parse(localStorage.getItem("membresias"));
    let i = mems.findIndex(x => x.id == id);

    mems[i].nombre = document.getElementById("memNombre").value;
    mems[i].duracion = document.getElementById("memDuracion").value;
    mems[i].precio = document.getElementById("memPrecio").value;

    localStorage.setItem("membresias", JSON.stringify(mems));

    alert("Membresía actualizada");
    limpiarFormularioMembresia();
    cargarTablaMembresias();
    cargarComboMembresias();
}

// Eliminar membresía
function eliminarMembresia() {
    let id = document.getElementById("memId").value;

    if (!id) {
        alert("Selecciona una membresía para eliminar.");
        return;
    }

    let mems = JSON.parse(localStorage.getItem("membresias"));
    mems = mems.filter(x => x.id != id);

    localStorage.setItem("membresias", JSON.stringify(mems));

    alert("Membresía eliminada");
    limpiarFormularioMembresia();
    cargarTablaMembresias();
    cargarComboMembresias();
}

// Tabla membresías
function cargarTablaMembresias() {
    let mems = JSON.parse(localStorage.getItem("membresias"));
    let tabla = document.getElementById("tablaMembresias");

    if (!tabla) return;

    tabla.innerHTML = `
        <tr>
            <th>ID</th><th>Nombre</th><th>Duración</th><th>Precio</th>
        </tr>
    `;

    mems.forEach(m => {
        tabla.innerHTML += `
            <tr>
                <td>${m.id}</td>
                <td>${m.nombre}</td>
                <td>${m.duracion} meses</td>
                <td>$${m.precio}</td>
            </tr>
        `;
    });
}

// Combo búsqueda membresías
function cargarComboMembresias() {
    let combo = document.getElementById("comboBuscarMembresia");
    if (!combo) return;

    combo.innerHTML = `<option value="">Selecciona una membresía</option>`;

    let mems = JSON.parse(localStorage.getItem("membresias"));

    mems.forEach(m => {
        combo.innerHTML += `<option value="${m.id}">${m.id} - ${m.nombre}</option>`;
    });
}

// Limpiar formulario
function limpiarFormularioMembresia() {
    document.getElementById("memId").value = "";
    document.getElementById("memNombre").value = "";
    document.getElementById("memDuracion").value = "";
    document.getElementById("memPrecio").value = "";
}



// =========================================================
// ==================== CRUD DE RUTINAS =====================
// =========================================================

if (window.location.pathname.includes("rutinas.html")) {
    cargarCombosRutinas();
    cargarTablaRutinas();
    cargarComboRutinas();
}

// Cargar combos
function cargarCombosRutinas() {

    // Clientes
    let comboCli = document.getElementById("rutClienteId");
    let clientes = JSON.parse(localStorage.getItem("clientes"));

    comboCli.innerHTML = `<option value="">Seleccione Cliente</option>`;
    clientes.forEach(c => {
        comboCli.innerHTML += `<option value="${c.id}">${c.id} - ${c.nombre}</option>`;
    });

    // Membresías
    let comboMem = document.getElementById("rutMembresiaId");
    let mems = JSON.parse(localStorage.getItem("membresias"));

    comboMem.innerHTML = `<option value="">Seleccione Membresía</option>`;
    mems.forEach(m => {
        comboMem.innerHTML += `<option value="${m.id}" data-duracion="${m.duracion}">${m.id} - ${m.nombre}</option>`;
    });
}

// Agregar Rutina
function agregarRutina() {
    let clienteId = document.getElementById("rutClienteId").value;
    let membresiaId = document.getElementById("rutMembresiaId").value;
    let tipo = document.getElementById("rutTipo").value;
    let nivel = document.getElementById("rutNivel").value;
    let duracion = document.getElementById("rutDuracion").value;
    let fechaInicio = document.getElementById("rutFechaInicio").value;
    let fechaFinManual = document.getElementById("rutFechaFin").value;

    if (!clienteId || !membresiaId || !tipo || !nivel || !duracion || !fechaInicio) {
        alert("Faltan campos obligatorios");
        return;
    }

    let mems = JSON.parse(localStorage.getItem("membresias"));
    let mem = mems.find(x => x.id == membresiaId);

    // Si el usuario NO elige fecha fin, se calcula automáticamente
    let fechaFin = fechaFinManual || (() => {
        let fInicio = new Date(fechaInicio);
        fInicio.setMonth(fInicio.getMonth() + parseInt(mem.duracion));
        return fInicio.toISOString().split("T")[0];
    })();

    let rutinas = JSON.parse(localStorage.getItem("rutinas"));

    let nueva = {
        id: rutinas.length + 1,
        clienteId,
        membresiaId,
        tipo,
        nivel,
        duracion,
        fechaInicio,
        fechaFin
    };

    rutinas.push(nueva);
    localStorage.setItem("rutinas", JSON.stringify(rutinas));

    alert("Rutina registrada");
    limpiarFormularioRutina();
    cargarTablaRutinas();
    cargarComboRutinas();
}


// Buscar Rutina
function buscarRutinaPorID() {
    let id = document.getElementById("comboBuscarRutina").value;
    if (id === "") return;

    let rutinas = JSON.parse(localStorage.getItem("rutinas"));
    let r = rutinas.find(x => x.id == id);

    if (!r) return;

    document.getElementById("rutinaId").value = r.id;
    document.getElementById("rutClienteId").value = r.clienteId;
    document.getElementById("rutMembresiaId").value = r.membresiaId;
    document.getElementById("rutTipo").value = r.tipo;
    document.getElementById("rutNivel").value = r.nivel;
    document.getElementById("rutDuracion").value = r.duracion;
    document.getElementById("rutFechaInicio").value = r.fechaInicio;
    document.getElementById("rutFechaFin").value = r.fechaFin;
}

// Modificar Rutina
function modificarRutina() {
    let id = document.getElementById("rutinaId").value;
    if (!id) {
        alert("Selecciona una rutina");
        return;
    }

    let clienteId = document.getElementById("rutClienteId").value;
    let membresiaId = document.getElementById("rutMembresiaId").value;
    let tipo = document.getElementById("rutTipo").value;
    let nivel = document.getElementById("rutNivel").value;
    let duracion = document.getElementById("rutDuracion").value;
    let fechaInicio = document.getElementById("rutFechaInicio").value;
    let fechaFinManual = document.getElementById("rutFechaFin").value;

    let mems = JSON.parse(localStorage.getItem("membresias"));
    let mem = mems.find(x => x.id == membresiaId);

    let fechaFin = fechaFinManual || (() => {
        let fInicio = new Date(fechaInicio);
        fInicio.setMonth(fInicio.getMonth() + parseInt(mem.duracion));
        return fInicio.toISOString().split("T")[0];
    })();

    let rutinas = JSON.parse(localStorage.getItem("rutinas"));
    let i = rutinas.findIndex(x => x.id == id);

    rutinas[i] = {
        id: parseInt(id),
        clienteId,
        membresiaId,
        tipo,
        nivel,
        duracion,
        fechaInicio,
        fechaFin
    };

    localStorage.setItem("rutinas", JSON.stringify(rutinas));

    alert("Rutina modificada");
    limpiarFormularioRutina();
    cargarTablaRutinas();
    cargarComboRutinas();
}


// Eliminar Rutina
function eliminarRutina() {
    let id = document.getElementById("rutinaId").value;
    if (!id) {
        alert("Selecciona una rutina");
        return;
    }

    let rutinas = JSON.parse(localStorage.getItem("rutinas"));
    rutinas = rutinas.filter(x => x.id != id);

    localStorage.setItem("rutinas", JSON.stringify(rutinas));

    alert("Rutina eliminada");
    limpiarFormularioRutina();
    cargarTablaRutinas();
    cargarComboRutinas();
}

// Tabla de Rutinas
function cargarTablaRutinas() {
    let rutinas = JSON.parse(localStorage.getItem("rutinas"));
    let tabla = document.getElementById("tablaRutinas");
    let clientes = JSON.parse(localStorage.getItem("clientes"));
    let mems = JSON.parse(localStorage.getItem("membresias"));

    if (!tabla) return;

    tabla.innerHTML = `
        <tr>
            <th>ID</th><th>Cliente</th><th>Membresía</th><th>Tipo</th>
            <th>Nivel</th><th>Duración</th><th>Inicio</th><th>Fin</th>
        </tr>
    `;

    rutinas.forEach(r => {
        let cli = clientes.find(c => c.id == r.clienteId);
        let mem = mems.find(m => m.id == r.membresiaId);

        tabla.innerHTML += `
            <tr>
                <td>${r.id}</td>
                <td>${cli ? cli.nombre : "N/A"}</td>
                <td>${mem ? mem.nombre : "N/A"}</td>
                <td>${r.tipo}</td>
                <td>${r.nivel}</td>
                <td>${r.duracion} min</td>
                <td>${r.fechaInicio}</td>
                <td>${r.fechaFin}</td>
            </tr>
        `;
    });
}

// Combo búsqueda
function cargarComboRutinas() {
    let combo = document.getElementById("comboBuscarRutina");
    if (!combo) return;

    combo.innerHTML = `<option value="">Selecciona una rutina</option>`;

    let rutinas = JSON.parse(localStorage.getItem("rutinas"));

    rutinas.forEach(r => {
        combo.innerHTML += `<option value="${r.id}">${r.id} - ${r.tipo}</option>`;
    });
}

// Limpiar
function limpiarFormularioRutina() {
    document.getElementById("rutinaId").value = "";
    document.getElementById("rutClienteId").value = "";
    document.getElementById("rutMembresiaId").value = "";
    document.getElementById("rutTipo").value = "";
    document.getElementById("rutNivel").value = "";
    document.getElementById("rutDuracion").value = "";
    document.getElementById("rutFechaInicio").value = "";
    document.getElementById("rutFechaFin").value = "";
}
