// ==========================
// GUARDAR RUTINA
// ==========================
function guardarRutina() {
    const id = document.getElementById("id_cliente").value;

    // lista de ejercicios
    const ejercicios = obtenerEjerciciosComoJSON(); //función original

    let f = new FormData();
    f.append("id_cliente", id);
    f.append("ejercicios", JSON.stringify(ejercicios));

    fetch("rutinas_guardar.php", {
        method: "POST",
        body: f
    })
    .then(r => r.text())
    .then(res => {
        if (res === "OK") {
            alert("Rutina guardada");
            cargarRutinas();
        } else {
            alert("Error");
        }
    });
}

// ==========================
// LISTAR RUTINAS
// ==========================
function cargarRutinas() {
    fetch("rutinas_listar.php")
    .then(r => r.json())
    .then(lista => {
        const tabla = document.getElementById("tablaRutinas");
        tabla.innerHTML = "";

        lista.forEach(r => {
            tabla.innerHTML += `
                <tr>
                    <td>${r.id}</td>
                    <td>${r.id_cliente}</td>
                    <td>${JSON.stringify(r.ejercicios)}</td>
                    <td>
                        <button onclick="eliminarRutina(${r.id})">Eliminar</button>
                    </td>
                </tr>
            `;
        });
    });
}

// ==========================
// ELIMINAR RUTINA
// ==========================
function eliminarRutina(id) {
    const f = new FormData();
    f.append("id", id);

    fetch("rutinas_eliminar.php", {
        method: "POST",
        body: f
    })
    .then(r => r.text())
    .then(resp => {
        if (resp === "OK") {
            alert("Rutina eliminada");
            cargarRutinas();
        }
    });
}
