// ==========================
// LOGIN
// ==========================
function login() {
    const f = new FormData(document.getElementById("formLogin"));

    fetch("api/usuario_login.php", {
    method: "POST",
    body: datos
})
    .then(r => r.text())
    .then(res => {
        console.log("Respuesta del servidor:", res);

        if (res === "NO_USER") {
            alert("Usuario no encontrado");
            return;
        }

        if (res === "WRONG_PASS") {
            alert("Contraseña incorrecta");
            return;
        }

        let user = JSON.parse(res); // <--- aquí ya llega el JSON correcto
        localStorage.setItem("usuario", JSON.stringify(user));
        window.location.href = "paginas/home.html"; // <--- redirección correcta
    });
}

