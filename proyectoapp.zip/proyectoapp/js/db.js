// Inicializar base si no existe
if (!localStorage.getItem("usuarios")) {
    localStorage.setItem("usuarios", JSON.stringify([]));
}

if (!localStorage.getItem("clientes")) {
    localStorage.setItem("clientes", JSON.stringify([]));
}

if (!localStorage.getItem("membresias")) {
    localStorage.setItem("membresias", JSON.stringify([]));
}

if (!localStorage.getItem("rutinas")) {
    localStorage.setItem("rutinas", JSON.stringify([]));
}

//  IMPORTANTE: inicializar sesión
if (!localStorage.getItem("sesion")) {
    localStorage.setItem("sesion", JSON.stringify(null));
}
