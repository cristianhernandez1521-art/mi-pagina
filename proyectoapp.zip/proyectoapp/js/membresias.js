// ==========================
// GUARDAR MEMBRESÍA
// ==========================
function guardarMembresia() {
    const f = new FormData(document.getElementById("formMembresias"));

    fetch("membresias_guardar.php", {
        method: "POST",
        body: f
    })
    .then(r => r.text())
    .then(res => {
        if (res === "OK") {
            alert("Membresía guardada");
            cargarMembresias();
        } else {
            alert("Error");
        }
    });
}

// ==========================
// LISTAR MEMBRESÍAS
// ==========================
function cargarMembresias() {
    fetch("membresias_listar.php")
    .then(r => r.json())
    .then(lista => {
        const tabla = document.getElementById("tablaMembresias");
        tabla.innerHTML = "";

        lista.forEach(m => {
            tabla.innerHTML += `
                <tr>
                    <td>${m.id}</td>
                    <td>${m.nombre}</td>
                    <td>${m.duracion_dias} días</td>
                    <td>$${m.precio}</td>
                    <td>
                        <button onclick="eliminarMembresia(${m.id})">Eliminar</button>
                    </td>
                </tr>
            `;
        });
    });
}

// ==========================
// ELIMINAR MEMBRESÍA
// ==========================
function eliminarMembresia(id) {
    let f = new FormData();
    f.append("id", id);

    fetch("membresias_eliminar.php", {
        method: "POST",
        body: f
    })
    .then(r => r.text())
    .then(res => {
        if (res === "OK") {
            alert("Eliminada");
            cargarMembresias();
        }
    });
}
