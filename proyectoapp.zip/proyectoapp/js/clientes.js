// =========================================================
// ========== CARGAR MEMBRESÍAS (FK) =======================
// =========================================================

async function cargarMembresias() {
    try {
        let res = await fetch("../api/membresias.php");
        let data = await res.json();

        if (!data.ok || !Array.isArray(data.data)) {
            throw "Formato inválido en membresías";
        }

        const combo = document.getElementById("clienteMembresia");
        combo.innerHTML = '<option value="">Seleccione membresía</option>';

        data.data.forEach(m => {
            combo.innerHTML += `<option value="${m.id}">${m.nombre}</option>`;
        });

    } catch (error) {
        alert("Error cargando membresías");
        console.error("ERROR MEMBRESÍAS:", error);
    }
}



// =========================================================
// ========== CARGAR LISTA DE CLIENTES =====================
// =========================================================

async function cargarClientes() {
    try {
        let res = await fetch("../api/clientes.php");
        let data = await res.json();

        if (!data.ok || !Array.isArray(data.data)) {
            throw "Formato inválido en clientes";
        }

        const tabla = document.querySelector("#tablaClientes tbody");
        tabla.innerHTML = "";

        data.data.forEach(c => {
            tabla.innerHTML += `
                <tr>
                    <td>${c.id}</td>
                    <td>${c.nombre}</td>
                    <td>${c.edad}</td>
                    <td>${c.telefono}</td>
                    <td>${c.membresia}</td>
                </tr>
            `;
        });

    } catch (error) {
        alert("Error cargando clientes");
        console.error("ERROR CLIENTES:", error);
    }
}



// =========================================================
// ========== CARGAR CLIENTES AL COMBO (PK) ================
// =========================================================

async function cargarComboClientes() {
    try {
        let res = await fetch("../api/clientes.php");
        let data = await res.json();

        if (!data.ok || !Array.isArray(data.data)) {
            throw "Formato inválido en combo clientes";
        }

        const combo = document.getElementById("comboBuscarCliente");
        combo.innerHTML = `<option value="">Selecciona un cliente</option>`;

        data.data.forEach(c => {
            combo.innerHTML += `<option value="${c.id}">${c.id} - ${c.nombre}</option>`;
        });

    } catch (error) {
        alert("Error cargando lista de clientes");
        console.error("ERROR COMBO CLIENTES:", error);
    }
}



// =========================================================
// ========== BUSCAR CLIENTE POR ID ========================
// =========================================================

document.getElementById("comboBuscarCliente").addEventListener("change", async function () {
    let id = this.value;
    if (id === "") return;

    try {
        let res = await fetch("../api/clientes.php?id=" + id);
        let data = await res.json();

        if (!data.ok) throw "No encontrado";

        let c = data.data;

        document.getElementById("clienteId").value = c.id;
        document.getElementById("clienteNombre").value = c.nombre;
        document.getElementById("clienteEdad").value = c.edad;
        document.getElementById("clienteTelefono").value = c.telefono;
        document.getElementById("clienteMembresia").value = c.membresia_id;

    } catch (error) {
        alert("Error buscando cliente");
        console.error(error);
    }
});



// =========================================================
// ========== INICIALIZAR PANTALLA =========================
// =========================================================

document.addEventListener("DOMContentLoaded", () => {
    cargarMembresias();
    cargarClientes();
    cargarComboClientes();
});
