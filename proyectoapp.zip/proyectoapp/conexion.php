<?php
$host = "localhost:3306";
$user = "root";
$pass = "";
$db = "gym_app";   // <-- Asegúrate de que este sea tu nombre real de BD

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}
?>